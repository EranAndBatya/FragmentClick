package com.example.fragmentex;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements MessageFragment.OnMessageReadListener {
   private  TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if(findViewById(R.id.frag1)!= null)

            if(savedInstanceState!= null)
            {
                return;
            }
        MessageFragment messageFragment = new MessageFragment();
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction().add(R.id.frag1,messageFragment,null);//הלבשת פרגמנט על החלק שלו באקטיביטי היחיד
        fragmentTransaction.commit();
    }

    @Override
    public void OnMessageRead(String massage) {

        textView= findViewById(R.id.txt_display_msg);
        textView.setText(massage);

    }
}
